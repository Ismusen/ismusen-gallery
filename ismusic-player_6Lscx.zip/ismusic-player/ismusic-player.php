<?php
/**
 * Plugin Name: Ismusen Music Player
 * Description: 为Ismusen博客添加音乐播放器功能
 * Version: 1.0
 * Author: Ismusen
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 创建数据库表
function ismusic_player_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ismusic_songs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        title varchar(255) NOT NULL,
        artist varchar(255) NOT NULL,
        src text NOT NULL,
        duration varchar(10) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // 插入示例数据
    $wpdb->insert(
        $table_name,
        array(
            'title' => '夏日微风',
            'artist' => '自然之声',
            'src' => 'https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3',
            'duration' => '2:45'
        )
    );
}
register_activation_hook(__FILE__, 'ismusic_player_create_table');

// 添加管理菜单
function ismusic_player_admin_menu() {
    add_menu_page(
        '音乐播放器管理',
        '音乐播放器',
        'manage_options',
        'ismusic-player',
        'ismusic_player_admin_page',
        'dashicons-format-audio',
        20
    );
}
add_action('admin_menu', 'ismusic_player_admin_menu');

// 管理页面
function ismusic_player_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ismusic_songs';
    
    // 处理表单提交
    if (isset($_POST['submit_song']) && check_admin_referer('add_song_nonce')) {
        $title = sanitize_text_field($_POST['title']);
        $artist = sanitize_text_field($_POST['artist']);
        $src = esc_url_raw($_POST['src']);
        $duration = sanitize_text_field($_POST['duration']);
        
        $wpdb->insert(
            $table_name,
            array(
                'title' => $title,
                'artist' => $artist,
                'src' => $src,
                'duration' => $duration
            ),
            array('%s', '%s', '%s', '%s')
        );
        
        echo '<div class="notice notice-success"><p>歌曲已添加！</p></div>';
    }
    
    // 处理删除请求
    if (isset($_GET['delete']) && check_admin_referer('delete_song_nonce')) {
        $id = intval($_GET['delete']);
        $wpdb->delete($table_name, array('id' => $id));
        echo '<div class="notice notice-success"><p>歌曲已删除！</p></div>';
    }
    
    // 获取所有歌曲
    $songs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>音乐播放器管理</h1>
        
        <h2>添加新歌曲</h2>
        <form method="post" action="">
            <?php wp_nonce_field('add_song_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="title">歌曲标题</label></th>
                    <td><input type="text" name="title" id="title" required class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="artist">艺术家</label></th>
                    <td><input type="text" name="artist" id"artist" required class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="src">音频URL</label></th>
                    <td>
                        <input type="url" name="src" id="src" required class="regular-text">
                        <p class="description">请输入音频文件的外部链接地址</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="duration">时长</label></th>
                    <td>
                        <input type="text" name="duration" id="duration" required class="small-text">
                        <p class="description">格式: 分:秒 (例如: 3:45)</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('添加歌曲', 'primary', 'submit_song'); ?>
        </form>
        
        <h2>歌曲列表</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>歌曲标题</th>
                    <th>艺术家</th>
                    <th>时长</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($songs) : ?>
                    <?php foreach ($songs as $song) : ?>
                        <tr>
                            <td><?php echo $song->id; ?></td>
                            <td><?php echo esc_html($song->title); ?></td>
                            <td><?php echo esc_html($song->artist); ?></td>
                            <td><?php echo esc_html($song->duration); ?></td>
                            <td>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ismusic-player&delete=' . $song->id), 'delete_song_nonce'); ?>" 
                                   onclick="return confirm('确定要删除这首歌曲吗？')">删除</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5">暂无歌曲</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// 创建短代码
function ismusic_player_shortcode() {
    ob_start();
    ?>
    <div class="ismusic-player">
        <div class="player-container">
            <div class="now-playing">
                <div class="track-info">
                    <h2>选择一首歌曲</h2>
                    <h3>艺术家</h3>
                    <div class="progress-area">
                        <div class="progress-bar">
                            <div class="progress"></div>
                        </div>
                        <div class="time">
                            <span class="current">0:00</span>
                            <span class="duration">0:00</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="controls">
                <button id="ismusic-prev"><span class="icon icon-prev"></span></button>
                <button class="play-pause" id="ismusic-play-pause"><span class="icon icon-play"></span></button>
                <button id="ismusic-next"><span class="icon icon-next"></span></button>
                
                <div class="loop-control">
                    <button class="loop-btn" id="ismusic-loop-btn" title="列表循环">
                        <span class="icon icon-repeat"></span>
                    </button>
                </div>
            </div>
            
            <div class="playlist-container">
                <div class="playlist-header">
                    <h2>播放列表</h2>
                    <div class="search-box">
                        <span class="icon icon-search"></span>
                        <input type="text" placeholder="搜索歌曲..." id="ismusic-search-input">
                    </div>
                </div>
                
                <ul class="playlist" id="ismusic-playlist">
                    <!-- 播放列表将通过JavaScript动态生成 -->
                </ul>
            </div>
            
            <div class="copyright">
                <p>所有歌曲不定时更新。音源来自于网络，如有侵权，请联系删除。</p>
            </div>
            
            <div class="back-container">
                <a href="<?php echo home_url(); ?>" class="back-link">
                    <span class="icon icon-back"></span> 返回首页
                </a>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('ismusic_player', 'ismusic_player_shortcode');

// 添加AJAX处理
function ismusic_player_ajax_handler() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ismusic_songs';
    $songs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
    
    wp_send_json($songs);
}
add_action('wp_ajax_get_ismusic_songs', 'ismusic_player_ajax_handler');
add_action('wp_ajax_nopriv_get_ismusic_songs', 'ismusic_player_ajax_handler');

// 添加脚本和样式
function ismusic_player_scripts() {
    // 加载CSS样式
    wp_enqueue_style('ismusic-player-style', plugin_dir_url(__FILE__) . 'player-style.css', array(), '1.0');
    
    // 加载JavaScript
    wp_enqueue_script('ismusic-player', plugin_dir_url(__FILE__) . 'player.js', array(), '1.0', true);
    
    // 本地化脚本，传递AJAX参数
    wp_localize_script('ismusic-player', 'ismusic_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'action' => 'get_ismusic_songs'
    ));
}
add_action('wp_enqueue_scripts', 'ismusic_player_scripts');