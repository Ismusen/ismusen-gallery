document.addEventListener('DOMContentLoaded', function() {
    // 从服务器获取歌曲数据
    function fetchSongs() {
        fetch(ismusic_ajax.ajax_url + '?action=' + ismusic_ajax.action)
            .then(response => response.json())
            .then(songs => {
                initPlayer(songs);
            })
            .catch(error => {
                console.error('获取歌曲列表失败:', error);
                // 使用默认歌曲作为后备
                const defaultSongs = [
                    {
                        title: "示例歌曲",
                        artist: "示例艺术家",
                        src: "https://assets.mixkit.co/music/preview/mixkit-tech-house-vibes-130.mp3",
                        duration: "2:45"
                    }
                ];
                initPlayer(defaultSongs);
            });
    }

    // 初始化播放器
    function initPlayer(songs) {
        // 获取DOM元素
        const playPauseBtn = document.getElementById('ismusic-play-pause');
        const prevBtn = document.getElementById('ismusic-prev');
        const nextBtn = document.getElementById('ismusic-next');
        const loopBtn = document.getElementById('ismusic-loop-btn');
        const audio = new Audio();
        const progressBar = document.querySelector('.progress');
        const currentTimeEl = document.querySelector('.current');
        const durationEl = document.querySelector('.duration');
        const playlistEl = document.getElementById('ismusic-playlist');
        const trackTitle = document.querySelector('.track-info h2');
        const trackArtist = document.querySelector('.track-info h3');
        const searchInput = document.getElementById('ismusic-search-input');

        let currentSongIndex = 0;
        let isPlaying = false;
        let loopMode = 'list'; // 'list' 或 'single'

        // 初始化播放列表
        function initPlaylist() {
            playlistEl.innerHTML = '';
            songs.forEach((song, index) => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span class="num">${index + 1}</span>
                    <div class="title">
                        <h4>${song.title}</h4>
                        <p>${song.artist}</p>
                    </div>
                    <span class="duration">${song.duration}</span>
                `;
                li.addEventListener('click', () => playSong(index));
                playlistEl.appendChild(li);
            });
        }

        // 播放歌曲
        function playSong(index) {
            if (index >= 0 && index < songs.length) {
                currentSongIndex = index;
                const song = songs[index];
                
                audio.src = song.src;
                audio.play();
                
                trackTitle.textContent = song.title;
                trackArtist.textContent = song.artist;
                
                isPlaying = true;
                playPauseBtn.innerHTML = '<span class="icon icon-pause"></span>';
                
                // 更新播放列表中的活动项目
                document.querySelectorAll('.playlist li').forEach((li, i) => {
                    if (i === index) {
                        li.classList.add('playing');
                    } else {
                        li.classList.remove('playing');
                    }
                });
            }
        }

        // 播放/暂停切换
        function togglePlayPause() {
            if (isPlaying) {
                audio.pause();
                playPauseBtn.innerHTML = '<span class="icon icon-play"></span>';
            } else {
                audio.play();
                playPauseBtn.innerHTML = '<span class="icon icon-pause"></span>';
            }
            isPlaying = !isPlaying;
        }

        // 下一首
        function nextSong() {
            let nextIndex;
            if (loopMode === 'single') {
                // 单曲循环，播放同一首
                nextIndex = currentSongIndex;
            } else {
                // 列表循环，播放下一首
                nextIndex = (currentSongIndex + 1) % songs.length;
            }
            playSong(nextIndex);
        }

        // 上一首
        function prevSong() {
            let prevIndex;
            if (loopMode === 'single') {
                // 单曲循环，播放同一首
                prevIndex = currentSongIndex;
            } else {
                // 列表循环，播放上一首
                prevIndex = (currentSongIndex - 1 + songs.length) % songs.length;
            }
            playSong(prevIndex);
        }

        // 切换循环模式
        function toggleLoopMode() {
            if (loopMode === 'list') {
                loopMode = 'single';
                loopBtn.innerHTML = '<span class="icon icon-repeat-one"></span>';
                loopBtn.title = '单曲循环';
            } else {
                loopMode = 'list';
                loopBtn.innerHTML = '<span class="icon icon-repeat"></span>';
                loopBtn.title = '列表循环';
            }
            loopBtn.classList.toggle('active');
        }

        // 更新进度条
        function updateProgress(e) {
            const { duration, currentTime } = e.srcElement;
            if (duration) {
                const progressPercent = (currentTime / duration) * 100;
                progressBar.style.width = `${progressPercent}%`;
                
                // 更新时间显示
                const durationMinutes = Math.floor(duration / 60);
                const durationSeconds = Math.floor(duration % 60);
                durationEl.textContent = `${durationMinutes}:${durationSeconds < 10 ? '0' : ''}${durationSeconds}`;
                
                const currentMinutes = Math.floor(currentTime / 60);
                const currentSeconds = Math.floor(currentTime % 60);
                currentTimeEl.textContent = `${currentMinutes}:${currentSeconds < 10 ? '0' : ''}${currentSeconds}`;
            }
        }

        // 设置进度条
        function setProgress(e) {
            const width = this.clientWidth;
            const clickX = e.offsetX;
            const duration = audio.duration;
            audio.currentTime = (clickX / width) * duration;
        }

        // 搜索功能
        function searchSongs() {
            const query = searchInput.value.toLowerCase();
            document.querySelectorAll('.playlist li').forEach((li, index) => {
                const song = songs[index];
                const isMatch = song.title.toLowerCase().includes(query) || 
                               song.artist.toLowerCase().includes(query);
                li.style.display = isMatch ? 'flex' : 'none';
            });
        }

        // 事件监听
        playPauseBtn.addEventListener('click', togglePlayPause);
        nextBtn.addEventListener('click', nextSong);
        prevBtn.addEventListener('click', prevSong);
        loopBtn.addEventListener('click', toggleLoopMode);
        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('ended', nextSong);
        document.querySelector('.progress-bar').addEventListener('click', setProgress);
        searchInput.addEventListener('input', searchSongs);

        // 初始化
        initPlaylist();
        if (songs.length > 0) {
            playSong(0);
        }
    }

    // 开始获取歌曲
    fetchSongs();
});